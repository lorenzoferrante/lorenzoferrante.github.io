"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var SubEmitter_1 = require("./SubEmitter");
var emitter = new SubEmitter_1.SubEmitter();
exports.emitter = emitter;
//# sourceMappingURL=emit.js.map