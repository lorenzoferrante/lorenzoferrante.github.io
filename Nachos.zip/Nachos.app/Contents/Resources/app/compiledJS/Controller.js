"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Movie_1 = require("./Movie");
var Torrent_1 = require("./Torrent");
var Process_1 = require("./Process");
var emit_1 = require("./emit");
var MovieSub_1 = require("./MovieSub");
var Utils_1 = require("./Utils");
var Notification_1 = require("./Notification");
var EventEmitter = require('events').EventEmitter;
var pt = require('path');
var yify = require('../js/yify');
var exec = require('child_process').exec;
var $ = require('jQuery');
var player = require('../js/player');
var humanizeDuration = require('humanize-duration');
var open = require('open');
var peerflix = require('peerflix');
var network = require('network-address');
var numeral = require('numeral');
var readTorrent = require('read-torrent');
var fs = require('fs');
var Controller = (function () {
    function Controller() {
        this.utils = new Utils_1.Utils();
        this.noti = new Notification_1.Notification();
        this.peerflixProc = new Process_1.Process();
        this.movieList = [];
        this.torrentList = [];
    }
    // Methods
    /* Search torrent given the title using YIFY API */
    Controller.prototype.searchTorrent = function (query) {
        var _this = this;
        this.movieList = [];
        this.torrentList = [];
        yify.search(query, function (error, result) {
            if (error) {
                console.log(error);
                _this.noti.netError();
                return;
            }
            if (result.length == 0) {
                $('#no-res').show();
                return;
            }
            else {
                $('#no-res').hide();
            }
            console.log(result);
            // Buttons to display for movie quality
            var qualityBtn = '';
            // reuslt is a JSON object
            for (var _i = 0, result_1 = result; _i < result_1.length; _i++) {
                var mv = result_1[_i];
                var qualityBtn_1 = '';
                for (var _a = 0, _b = mv.torrents; _a < _b.length; _a++) {
                    var tor = _b[_a];
                    _this.torrentList.push(new Torrent_1.Torrent(mv.state, tor.hash, tor.quality, tor.size, tor.url));
                    if (tor.quality == '720p') {
                        qualityBtn_1 += '<a href="javascript:void(0)" class="btn btn-primary watch 720p" id="' + mv.imdb_code + '">720p</a>';
                    }
                    else if (tor.quality == '1080p') {
                        qualityBtn_1 += '<a href="javascript:void(0)" class="btn btn-primary watch 1080p" id="' + mv.imdb_code + '">1080p</a>';
                    }
                    else if (tor.quality == '3D') {
                        qualityBtn_1 += '<a href="javascript:void(0)" class="btn btn-primary watch 3D" id="' + mv.imdb_code + '">3D</a>';
                    }
                }
                var dur = String(humanizeDuration(mv.runtime * 60000));
                var trailer = 'https://www.youtube.com/watch?v=' + mv.yt_trailer_code;
                _this.movie = new Movie_1.Movie(mv.title, mv.background_image_original, mv.medium_cover_image, mv.summary, mv.magnet, mv.imdb_code, mv.year, dur, trailer, _this.torrentList);
                //console.log(mv.magnet)
                // Get subtitles
                var mvSub = new MovieSub_1.MovieSub(_this.movie);
                emit_1.emitter.receiveSubs(_this.movie);
                _this.movieList.push(_this.movie);
                //$('#results').append('<li class="res"><div class="card" style="width: 100%;"><img class="card-img-top" src="'+this.movie.getBgImage()+'"><div class="card-block"><img src="'+this.movie.getCoverImage()+'" class="poster"><h4 class="card-title">'+this.movie.getTitle()+'<br><span class="badge badge-pill badge-success">Size: '+this.newTorrent.getSize()+'</span><span class="badge badge-pill badge-primary">'+this.newTorrent.getQuality()+'</span><span class="badge badge-pill badge-info">Year: '+this.movie.getYear()+'</span></h4><p class="card-text">'+this.movie.getDesc()+'</p><a href="#'+$(this).attr("id")+'" class="btn btn-primary watch" id="'+this.movie.getIMDB()+'">Watch!</a></p><a href="#'+$(this).attr("id")+'" class="btn btn-primary sub" id="'+this.movie.getIMDB()+'">Subtitles</a></div></div></li>')
                //$('#results').append('<li class="res"><div class="card" style="width: 100%;"><img class="card-img-top" src="'+this.movie.getBgImage()+'"><div class="card-block"><img src="'+this.movie.getCoverImage()+'" class="poster"><h4 class="card-title">'+this.movie.getTitle()+'<br><span class="badge badge-pill badge-success">'+this.newTorrent.getSize()+'</span><span class="badge badge-pill badge-primary">'+this.newTorrent.getQuality()+'</span><span class="badge badge-pill badge-info"> '+this.movie.getYear()+'</span><span class="badge badge-pill badge-warning">'+this.movie.getDuration()+'</span></h4><p class="card-text">'+this.movie.getDesc()+'</p><div><a href="#'+$(this).attr("id")+'" class="btn btn-primary watch" id="'+this.movie.getIMDB()+'">Watch!</a><a href="#'+$(this).attr("id")+'" class="btn btn-info trailer" id="'+this.movie.getIMDB()+'">Trailer</a><ul class="list-lang '+this.movie.getIMDB()+'"></ul></div></div></div></li>')
                $('#results').append('<li class="res"><div class="card" style="width: 100%;"> <div class="img-cont"><img class="card-img-top" src="' + _this.movie.getBgImage() + '"></div> <div class="card-block"><div class="poster-box"><img src="' + _this.movie.getCoverImage() + '" class="poster"></div> <h4 class="card-title">' + _this.movie.getTitle() + ' <br><span class="badge badge-pill badge-info">' + _this.movie.getYear() + '</span> <span class="badge badge-pill badge-warning">' + _this.movie.getDuration() + '</span> </h4> <p class="card-text">' + _this.movie.getDesc() + '</p><div> <h5 style="margin-top: 20px;">Watch:</h5> <a href="javascript:void(0)" class="btn btn-info trailer" id="' + _this.movie.getIMDB() + '">Trailer</a> ' + qualityBtn_1 + ' <br><br><h5 style="margin-top: 20px;">Subtitles:</h5> <ul class="list-lang ' + _this.movie.getIMDB() + '"></ul> </div></div></div></li>');
            }
        });
    };
    Controller.prototype.bytes = function (num) {
        return numeral(num).format('0.0b');
    };
    /* Methods to control Peerflix */
    Controller.prototype.peerflixManager = function (magnet, path, mv) {
        var _this = this;
        readTorrent(magnet, function (err, torrent) {
            console.log(torrent);
            // TODO: Gestire errore
            if (err)
                return;
            var engine = peerflix(torrent);
            var downloadedPercentage = 0;
            var verified = 0;
            var ready = false;
            engine.on('ready', function () {
                console.log('Ready to download the torrent.');
                ready = true;
            });
            engine.server.on('listening', function () {
                var addr = 'http://' + network() + ':' + engine.server.address().port;
                console.log(addr);
                // Write file
                var dataToWrite;
                if (path != '') {
                    player.serveSubtitle(path);
                    dataToWrite = addr + '\ntrue';
                }
                else {
                    dataToWrite = addr + '\nfalse';
                }
                fs.writeFile(__dirname + '/../server.txt', dataToWrite, function (err) {
                    if (err)
                        console.log(err);
                    console.log('File server.txt written');
                });
                _this.noti.playing(mv);
                player.createPlayer();
                var p = _this.peerflixProc.retrievePIDByName();
            });
            engine.on('verify', function () {
                verified++;
                downloadedPercentage = Math.floor(verified / engine.torrent.pieces.length * 100);
                if (ready)
                    console.log('Downloaded: ' + downloadedPercentage + '% at speed: ' + _this.bytes(engine.swarm.downloadSpeed()) + '/s');
            });
        });
    };
    /* Stream a torrent using VLC and Peerflix from command line */
    Controller.prototype.streamTorrent = function (movieID, movieQual) {
        console.log(movieQual);
        for (var _i = 0, _a = this.movieList; _i < _a.length; _i++) {
            var mv = _a[_i];
            if (mv.getIMDB() == movieID) {
                // Get chosen quality
                var magnet = mv.getMagnetFromQuality(movieQual);
                // Download Subtitle
                if (mv.getSubs().length > 0) {
                    var subPath = mv.getSubPath();
                    this.peerflixManager(magnet, subPath, mv);
                }
                else {
                    this.peerflixManager(magnet, '', mv);
                }
                console.log('Playing: ' + mv.getTitle());
            }
        }
    };
    /* Kill current Peerflix process and the associated VLC process */
    Controller.prototype.closePeerflix = function () {
        var pid = this.peerflixProc.getPID();
        console.log('Killing Peerflix with PID: ' + pid);
        this.peerflixProc.killProcess();
    };
    Controller.prototype.setSubLang = function (movieID, movieLang) {
        for (var _i = 0, _a = this.movieList; _i < _a.length; _i++) {
            var mv = _a[_i];
            if (mv.getIMDB() == movieID) {
                for (var _b = 0, _c = mv.getSubs(); _b < _c.length; _b++) {
                    var s = _c[_b];
                    console.log(s.getLang() + ' - ' + movieLang);
                    if (s.getLang() == movieLang) {
                        mv.setSubPath(s.getLink());
                    }
                }
            }
        }
    };
    Controller.prototype.openTrailer = function (movieID) {
        for (var _i = 0, _a = this.movieList; _i < _a.length; _i++) {
            var mv = _a[_i];
            if (mv.getIMDB() == movieID) {
                // Open trailer in browser
                console.log(mv.getTrailerLink());
                open(mv.getTrailerLink());
            }
        }
    };
    return Controller;
}());
exports.Controller = Controller;
//# sourceMappingURL=Controller.js.map