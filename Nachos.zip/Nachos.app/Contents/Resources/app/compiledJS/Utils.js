"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var dns = require('dns');
var fs = require('fs');
var exec = require('child_process').exec;
var zlib = require('zlib');
var Utils = (function () {
    function Utils() {
    }
    /* Methods */
    /* Check for internet connection */
    Utils.prototype.checkConnection = function () {
        dns.lookup('google.com', function (err) {
            if (err && err.code == 'ENOTFOUND') {
                console.log('[Error] connection failed');
                return false;
            }
            else {
                console.log('[Success] connection established');
                return true;
            }
        });
        return false;
    };
    /* Generate random string */
    Utils.prototype.makeid = function () {
        var text = "", i;
        var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
        for (i = 0; i < 5; i++)
            text += possible.charAt(Math.floor(Math.random() * possible.length));
        return text;
    };
    return Utils;
}());
exports.Utils = Utils;
//# sourceMappingURL=Utils.js.map