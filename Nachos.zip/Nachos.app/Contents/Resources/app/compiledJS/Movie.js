"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Utils_1 = require("./Utils");
var $ = require('jQuery');
var Sub = (function () {
    function Sub(title, path, lang, movieIMDB) {
        this.title = title;
        this.path = path;
        this.lang = lang;
        this.movieIMDB = movieIMDB;
    }
    // Getters
    Sub.prototype.getTitle = function () {
        return this.title;
    };
    Sub.prototype.getLang = function () {
        return this.lang;
    };
    Sub.prototype.getLink = function () {
        return this.path;
    };
    Sub.prototype.getIMDB = function () {
        return this.movieIMDB;
    };
    return Sub;
}());
var Movie = (function () {
    function Movie(title, bgImage, coverImage, desc, magnet, imdbCode, year, duration, trailerLink, torrent) {
        this.u = new Utils_1.Utils();
        this.title = title;
        this.id = this.u.makeid();
        this.bgImage = bgImage;
        this.coverImage = coverImage;
        this.desc = desc;
        this.magnet = magnet;
        this.imdbCode = imdbCode;
        this.year = year;
        this.duration = duration;
        this.trailerLink = trailerLink;
        this.torrent = torrent;
        this.subs = [];
    }
    // Getters
    Movie.prototype.getTitle = function () {
        return this.title;
    };
    Movie.prototype.getBgImage = function () {
        return this.bgImage;
    };
    Movie.prototype.getCoverImage = function () {
        return this.coverImage;
    };
    Movie.prototype.getDesc = function () {
        return this.desc;
    };
    Movie.prototype.getMagnet = function () {
        return this.magnet;
    };
    Movie.prototype.getIMDB = function () {
        return this.imdbCode;
    };
    Movie.prototype.getYear = function () {
        return this.year;
    };
    Movie.prototype.getDuration = function () {
        return this.duration;
    };
    Movie.prototype.getTrailerLink = function () {
        return this.trailerLink;
    };
    Movie.prototype.getTorrent = function () {
        return this.torrent;
    };
    Movie.prototype.getSubs = function () {
        return this.subs;
    };
    Movie.prototype.getID = function () {
        return this.id;
    };
    Movie.prototype.getSubPath = function () {
        return this.subPath;
    };
    // Setters
    Movie.prototype.setSubPath = function (path) {
        this.subPath = path;
    };
    Movie.prototype.setSubs = function (data) {
        //console.log('[EVENT] setting subs for: ' + this.title)
        var movieClass = '.' + this.imdbCode;
        if (data.length == 0) {
            $(movieClass).append('<li>No subtitles for this movie yet.</li>');
            return;
        }
        for (var _i = 0, data_1 = data; _i < data_1.length; _i++) {
            var sub = data_1[_i];
            var s = new Sub(this.title, sub.path.replace(/\s/g, ''), sub.langShort, this.imdbCode);
            if (sub.langShort == 'en') {
                $(movieClass).append('<li><a href="javascript:void(0)" id="' + this.imdbCode + '" class="sub"><span class="flag-icon flag-icon-gb flag-icon-squared" id="en"></span></a></li>');
            }
            else {
                $(movieClass).append('<li><a href="javascript:void(0)" id="' + this.imdbCode + '" class="sub"><span class="flag-icon flag-icon-it flag-icon-squared" id="it"></span></a></li>');
            }
            this.subs.push(s);
        }
    };
    // Methods
    Movie.prototype.getMagnetFromQuality = function (movieQual) {
        for (var _i = 0, _a = this.torrent; _i < _a.length; _i++) {
            var tor = _a[_i];
            console.log(movieQual + ' - ' + tor.getQuality());
            if (movieQual == tor.getQuality()) {
                return tor.getTorrentURL();
            }
        }
        // Get Notification for error
        return undefined;
    };
    Movie.prototype.getFavSub = function () {
        var path;
        for (var _i = 0, _a = this.getSubs(); _i < _a.length; _i++) {
            var s = _a[_i];
            if (s.getLang() == 'it') {
                return s.getLink();
            }
            else {
                path = s.getLink();
            }
        }
        return path;
    };
    return Movie;
}());
exports.Movie = Movie;
//# sourceMappingURL=Movie.js.map