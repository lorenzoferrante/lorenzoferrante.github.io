"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var exec = require('child_process').exec;
var Process = (function () {
    function Process() {
    }
    // Setters
    Process.prototype.setPID = function (pid) {
        this.pid = pid;
    };
    // Getters
    Process.prototype.getPID = function () {
        return this.pid;
    };
    // Methods
    Process.prototype.retrievePIDByName = function () {
        var _this = this;
        var cmd = 'ps -A | grep peerflix | head -c 5';
        exec(cmd, function (err, stdout, stderr) {
            if (err)
                console.log(err);
            console.log(stderr);
            _this.pid = stdout;
            return stdout;
        });
        return 0;
    };
    Process.prototype.killProcess = function () {
        var cmd = 'kill ' + this.pid;
        exec(cmd, function (err, stderr, stdout) {
            if (err) {
                console.log(err);
                return false;
            }
            console.log(stdout);
            console.log(stderr);
        });
        return true;
    };
    return Process;
}());
exports.Process = Process;
//# sourceMappingURL=Process.js.map