import { SubEmitter } from './SubEmitter'

const emitter = new SubEmitter()

export { emitter }
