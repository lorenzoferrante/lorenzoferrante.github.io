interface SubInterface {
    searchSub(movie: any): void
}
